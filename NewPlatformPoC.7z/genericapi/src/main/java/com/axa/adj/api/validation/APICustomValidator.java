package com.axa.adj.api.validation;

public interface APICustomValidator {
	<T> APIValidationContext validate(T wrapper);
}
