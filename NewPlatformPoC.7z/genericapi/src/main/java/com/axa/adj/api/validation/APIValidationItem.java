package com.axa.adj.api.validation;

public class APIValidationItem {
	private String itemName;
	private String itemValue;
	public APIValidationItem(String itemName, String itemValue) {
		this.itemName = itemName;
		this.itemValue = itemValue;
	}
	public String getItemName() {
		return itemName;
	}
	public String getItemValue() {
		return itemValue;
	}
}
