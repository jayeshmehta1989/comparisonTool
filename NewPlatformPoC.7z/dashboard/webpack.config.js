var webpack = require("webpack");

module.exports = {
  entry: './src/script/index.js',
  output: {
    path: __dirname + '/app/script',
    filename: 'bundle.js',
    publicPath: '/app/',
  },
  devServer: {
    //contentBase: '/app',
    port: 8080
  },
  //devtool: 'source-map',
  module: {
    preLoaders: [
      {
        test: /\.tag$/,
        exclude: /node_modules/,
        loader: 'riotjs-loader',
        query: {
          type: 'babel'
        }
      }
    ],
    loaders: [
      {
        test: /\.js$|\.tag$/,
        exclude: /node_modules/,
        loader: 'babel-loader'
      },
      { test: /bootstrap-sass\/assets\/javascripts\//, loader: 'imports?jQuery=jquery' },
      { test: /\.css$/, loaders: ['style', 'css'] },
      { test: /\.scss$/, loaders: ['style', 'css', 'sass'] },
      { test: /\.woff2?(\?v=[0-9]\.[0-9]\.[0-9])?$/, loader: 'url?limit=10000'},
      { test: /\.(ttf|eot|svg)(\?[\s\S]+)?$/, loader: 'file' }
    ]
  },
  plugins: [
    new webpack.optimize.UglifyJsPlugin(),
    new webpack.ProvidePlugin({
      riot: 'riot',
      jQuery: 'jquery',
      $: 'jquery'
    })
  ]
}