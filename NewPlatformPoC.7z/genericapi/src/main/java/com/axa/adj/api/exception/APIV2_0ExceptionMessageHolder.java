package com.axa.adj.api.exception;

import java.util.Locale;

import com.axa.adj.api.utils.LocalePropertyHolder;

public class APIV2_0ExceptionMessageHolder extends LocalePropertyHolder {

	private static final APIV2_0ExceptionMessageHolder INSTANCE = new APIV2_0ExceptionMessageHolder();
	private static ThreadLocal<Locale> CURRENT_LOCALE = new ThreadLocal<>();
	
	public static APIV2_0ExceptionMessageHolder getInstance() {
		return INSTANCE;
	}
	
	@Override
	protected String getPropertyFileName() {
		return "metainfo/properties_V2_0/API_V2_0_ExceptionMessage";
	}
	
	@Override
	public Locale getCurrentLocale() {
		return CURRENT_LOCALE.get();
	}
	
	public void setCurrentLocale(Locale locale) {
		CURRENT_LOCALE.set(locale);
	}

}
