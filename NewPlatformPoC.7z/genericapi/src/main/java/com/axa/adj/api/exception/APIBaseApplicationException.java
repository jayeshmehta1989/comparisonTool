package com.axa.adj.api.exception;

public class APIBaseApplicationException extends AbstractAPIBaseException {

	private static final long serialVersionUID = -967215942011048063L;

	public APIBaseApplicationException(String errorCode) {
		this(errorCode, null, null);
	}

	public APIBaseApplicationException(String errorCode, String[] args) {
		this(errorCode, args, null);
	}
	
	public APIBaseApplicationException(String errorCode, String[] args, Throwable cause) {
		super(errorCode, args, cause);
	}
	
	
}
