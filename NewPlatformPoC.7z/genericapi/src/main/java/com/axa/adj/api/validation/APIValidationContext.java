package com.axa.adj.api.validation;

import java.util.ArrayList;
import java.util.List;

public class APIValidationContext {
	private String validationType;
	private List<APIValidationItem> validationErrorList = new ArrayList<>();
	
	public APIValidationContext(String validationType) {
		this.validationType = validationType;
	}
	public String getValidationType() {
		return validationType;
	}
	public boolean isValidationOK() {
		return validationErrorList.size() == 0;
	}
	public void addErrorItem(APIValidationItem item) {
		validationErrorList.add(item);
	}
	public String createDetail() {
		String detail = "";
		for (APIValidationItem item : validationErrorList) {
			if (!detail.isEmpty()) {
				detail += ", ";
			}
			detail += item.getItemName() + "=" + item.getItemValue();
		}
		return "[" + getValidationType() +  "]" + detail;
	}
}
