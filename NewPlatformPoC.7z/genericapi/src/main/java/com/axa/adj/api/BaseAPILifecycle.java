package com.axa.adj.api;

import com.axa.adj.api.exception.APIValidationException;
import com.axa.adj.api.validation.APIValidationContext;
import com.axa.adj.api.validation.APIValidator;

public class BaseAPILifecycle {
	
	public void execute(BaseAPILifecycleContext context) {
		try {
			APIValidationContext validationContext = validate(context);
			if (!validationContext.isValidationOK()) {
				throw new APIValidationException(new String[]{validationContext.createDetail()});
			}
			executeLogic(context);
		} catch (Exception e) {
			context.setException(e);
			handleException(context);
		}
	}

	protected APIValidationContext validate(BaseAPILifecycleContext context) {
		return getValidator().validate(context);
	}
	
	protected APIValidator getValidator() {
		return null;
	}
	
	
	protected void executeLogic(BaseAPILifecycleContext context) {
	}
	

	protected void handleException(BaseAPILifecycleContext context) {
		context.getException().printStackTrace();
	}
}
