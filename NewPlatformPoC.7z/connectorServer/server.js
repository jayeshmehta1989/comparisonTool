var fs = require('fs');
var http = require('http');
var server = http.createServer();

server.on('request', function(req, res) {
  var stream = fs.createReadStream('index.html');
  res.writeHead(200, {'Content-Type': 'text/html'});
  stream.pipe(res);
});
var io = require('socket.io').listen(server);
var websocketPort = 3000;
var websocketApiPort = 3001;
server.listen(websocketPort);
console.log('websocket server is listening on port ' + websocketPort);

// connectionId - socket
var connectionMap = {};

// connectionId - destination connectionId
var destinationMap = {};

io.sockets.on('connection', function(socket) {
  socket.on('registerWithUUID', function(uuid) {
    console.log(uuid);
    connectionMap[uuid] = {connectionId: uuid, "socket": socket, timestamp: new Date()}
    socket.connectionId = uuid
  });
  socket.on('sync', function(data) {
    //console.log(data);
    var destinationId = destinationMap[socket.connectionId]
    var destinationSocket = connectionMap[destinationId];
    if (destinationSocket) {
      destinationSocket.socket.emit('sync', data);
    }
  });
  socket.on('tap', function() {
    var destinationId = destinationMap[socket.connectionId]
    var destinationSocket = connectionMap[destinationId];
    if (destinationSocket) {
      destinationSocket.socket.emit('tap');
    }
  })
  socket.on('disconnect', function() {
    for (key in connectionMap) {
      if (connectionMap[key].socket === socket) {
        delete connectionMap[key];
      }
    }
  });
});



///////////////////////////////////////////////////////

//server.js

//必要なパッケージの読み込み
var express    = require('express');
var app        = express();
var bodyParser = require('body-parser');

//POSTでdataを受け取るための記述
app.use(function(req, res, next) {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
  res.header("Access-Control-Allow-Methods", "GET, POST, PUT");
  next();
});
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

var port = process.env.PORT || websocketApiPort;

//expressでAPIサーバを使うための準備
var router = express.Router();

router.use(function(req, res, next) {
  //console.log('Something is happening.');
  next();
});

router.get('/', function(req, res) {
  res.json({ message: 'Successfully Posted a test message.' });
});

router.get('/connections', function(req, res) {
  var tmpConnections = [];
  for (key in connectionMap) {
    tmpConnections.push(connectionMap[key]);
  }
  tmpConnections.sort(function(a,b) {
    return b.timestamp.getTime() - a.timestamp.getTime();
  });
  var connections = [];
  
  res.json({ data: tmpConnections.map(function(element, index, array) {return {connectionId: element.connectionId}}) });
});

router.post('/connections/:id', function(req, res) {
  //console.log(req.params.id);
  var connection = connectionMap[req.params.id];
  if (connection != null) {
    connection.socket.emit('sync', {data: req.body});
    res.send("success");
  } else {
    res.send("fail");
  }
});

router.put('/connections/:id', function(req, res) {
  var connection = connectionMap[req.params.id];
  if (connection != null) {
    destinationMap[req.params.id] = req.body.id;
    destinationMap[req.body.id] = req.params.id;
    console.log("CONNECTED: " + req.params.id + "  -  " + req.body.id);
    res.send("success");
  } else {
    res.send("fail");
  }
});

//ルーティング登録
app.use('/api', router);

//サーバ起動
app.listen(port);
console.log('websocket API server is listening on port ' + port);