package com.axa.adj.api.utils;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.ResourceBundle;

/**
 * Load and hold property file per Locale.
 * Also provides String placeholder format function.
 * When using this class, create child class and make them singleton.
 */
public abstract class LocalePropertyHolder {

	private static final List<Locale> DEFAULT_LOCALE_LIST = Arrays.asList(new Locale[]{Locale.ROOT, Locale.JAPANESE});
	private static final Locale DEFAULT_LOCALE = Locale.ROOT;

	private Map<Locale, ResourceBundle> resourceBundleMap = new HashMap<Locale, ResourceBundle>();
	private boolean initialized = false;

	protected abstract String getPropertyFileName();
	protected abstract Locale getCurrentLocale();
	
	public String getValue(String key, String[] args) {
		initialize();
		return getValue(key, args, getCurrentLocale());
	}
	
	public String getValue(String key, String[] args, Locale locale) {
		initialize();
		if (locale == null) {
			locale = DEFAULT_LOCALE;
		}
		String message = resourceBundleMap.get(locale).getString(key);
		if (args != null) {
			for (int i = 0; i < args.length; i++) {
				message = message.replaceAll("\\{" + i + "\\}", args[i]);
			}
		}
		return message;
	}
	
	public void initialize() {
		if (initialized) {
			return;
		}
		for (Locale locale : getLocaleList()) {
			resourceBundleMap.put(locale, ResourceBundle.getBundle(getPropertyFileName(), locale));
		}
		initialized = true;
	}
	
	protected List<Locale> getLocaleList() {
		return DEFAULT_LOCALE_LIST;
	}
	
}
