package com.axa.adj.api;

import org.springframework.web.bind.annotation.RestController;

@RestController
public class BaseAPIController {

	public Object execute(String path, Object inputBean) {
		BaseAPILifecycleContext context = new BaseAPILifecycleContext();
		context.setPath(path);
		context.setPayload(inputBean);
		BaseAPILifecycle lifecycle = getLifecycle();
		lifecycle.execute(context);
		return context.getPayload();
	}
	
	protected BaseAPILifecycle getLifecycle() {
		return new BaseAPILifecycle();
	}
	
}
