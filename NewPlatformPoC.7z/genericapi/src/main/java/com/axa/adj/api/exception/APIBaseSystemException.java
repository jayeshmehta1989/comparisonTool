package com.axa.adj.api.exception;

public class APIBaseSystemException extends AbstractAPIBaseException {

	private static final long serialVersionUID = -9044897803226368042L;

	public APIBaseSystemException(String errorCode) {
		this(errorCode, null, null);
	}

	public APIBaseSystemException(String errorCode, String[] args) {
		this(errorCode, args, null);
	}
	
	public APIBaseSystemException(String errorCode, String[] args, Throwable cause) {
		super(errorCode, args, cause);
	}
	
}
