package com.axa.adj.api.validation;

import com.axa.adj.api.BaseAPILifecycleContext;

public class BaseAPIValidator implements APIValidator{

	@Override
	public APIValidationContext validate(BaseAPILifecycleContext context) {
		return new APIValidationContext("DEFAULT");
	}

}
