package com.axa.adj.api.exception;

public class APIValidationException extends APIBaseApplicationException {

	private static final long serialVersionUID = -7492819626902646252L;

	public APIValidationException(String[] detail) {
		super("EC_001", detail);
	}

}
