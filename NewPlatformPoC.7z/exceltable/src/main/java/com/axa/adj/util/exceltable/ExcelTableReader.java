package com.axa.adj.util.exceltable;

import java.io.File;

import com.axa.adj.util.exceltable.dto.ExcelTableContext;

public interface ExcelTableReader {

	ExcelTableContext read(File file);
}
