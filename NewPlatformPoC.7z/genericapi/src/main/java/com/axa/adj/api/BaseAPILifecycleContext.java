package com.axa.adj.api;

import java.util.HashMap;
import java.util.Map;

public class BaseAPILifecycleContext {

	private String path;
	
	private Object payload;
	
	private Object originalPayload;
	
	private Exception exception;
	
	private Map<String, Object> variableMap = new HashMap<>();

	public void setVariable(String key, Object value) {
		variableMap.put(key, value);
	}
	
	public Object getVariable(String key) {
		return variableMap.get(key);
	}

	public Object getPayload() {
		return payload;
	}

	public void setPayload(Object payload) {
		if (this.originalPayload == null) {
			this.originalPayload = payload;
		}
		this.payload = payload;
	}

	public Object getOriginalPayload() {
		return originalPayload;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public Exception getException() {
		return exception;
	}

	public void setException(Exception exception) {
		this.exception = exception;
	}

}
