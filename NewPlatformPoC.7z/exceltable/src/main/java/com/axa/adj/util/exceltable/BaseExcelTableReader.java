package com.axa.adj.util.exceltable;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

import com.axa.adj.util.exceltable.dto.ExcelDefinition;
import com.axa.adj.util.exceltable.dto.ExcelDefinition.ExcelCellAddress;
import com.axa.adj.util.exceltable.dto.ExcelDefinition.ExcelCellAddress.ValueType;
import com.axa.adj.util.exceltable.dto.ExcelTableContext;
import com.axa.adj.util.exceltable.dto.ExcelTableData;
import com.axa.adj.util.exceltable.dto.ExcelTableData.ExcelTableDataRow;

public class BaseExcelTableReader implements ExcelTableReader {

	private static final String TABLE_DELIMITER = "#";
	private static final String VALUE_PREFIX = "VAL_";
	private static final String TABLE_PREFIX = "TAB_";
	private static final String TABLE_PARAMETER_PREFIX = "PAR_";
	private static final String TABLE_VALUE_PREFIX = "VAL_";
	private static final String TABLE_DATA_START = "START";
	private static final String TABLE_CONDITION = "CONDITION";
	
	private static final String VALUE_TYPE_TEXT = "TEXT";
	private static final String VALUE_TYPE_NUM = "NUM";
	private static final String VALUE_TYPE_TRY_ANY = "TRY_ANY";


	@Override
	public ExcelTableContext read(File file) {

		Workbook wb;
		try {
			wb = WorkbookFactory.create(file);
		} catch (EncryptedDocumentException | InvalidFormatException | IOException e) {
			throw new RuntimeException(e);
		}
		
		ExcelTableContext context = new ExcelTableContext();
		for (int i = 0; i < wb.getNumberOfSheets(); i++) {
			Sheet sheet = wb.getSheetAt(i);	
			context.merge(load(sheet));
		}
		
		return context;
	}
	
	public ExcelTableContext load(Sheet sheet) {
		
		ExcelTableContext context = new ExcelTableContext();
		
		// check if this sheet is defined as ExcelTable or not
		Cell cell1_1 = getCell(sheet, 0, 0);
		if (cell1_1 == null || !"####".equals(getCellValue(cell1_1))) {
			return context;
		}
		
		long now = System.currentTimeMillis();
		System.out.println("read START:" + sheet.getSheetName());
		Map<String, ExcelDefinition> tableDefinitionMap = readTableDefinition(sheet);
		System.out.println(tableDefinitionMap);
		System.out.println("read END:" + (System.currentTimeMillis() - now));
		
		for (ExcelDefinition definition : tableDefinitionMap.values()) {
			System.out.println("load START:" + definition.getName());	
			now = System.currentTimeMillis();
			ExcelTableData tableData = loadData(sheet, definition);
			System.out.println("load END:" + (System.currentTimeMillis() - now));
			context.addExcelTableData(tableData);	
			System.out.println("##############");
//			System.out.println(tableData);
		}
		
		return context;
	}

	private Map<String, ExcelDefinition> readTableDefinition(Sheet sheet) {
		Map<String, ExcelDefinition> tableDefinitionMap = new HashMap<>();
		
		int maxRow = sheet.getLastRowNum();
		if (sheet.getRow(0) == null) {
			return tableDefinitionMap;
		}
		int maxCol = sheet.getRow(0).getLastCellNum();
		
		// read column definition
		for (int col = 1; col <= maxCol; col++) {
			Cell cell = getCell(sheet, 0, col);
			if (cell == null) {
				continue;
			}
			cell.setCellType( Cell.CELL_TYPE_STRING );
			String value = cell.getStringCellValue();
			if (value != null) {
				if (value.indexOf(',') > 0) {
					String[] valueArray = value.split(",");
					for (String tmpValue : valueArray) {
						addColumnDefinition(tableDefinitionMap, parse(tmpValue), col);
					}
				} else {
					addColumnDefinition(tableDefinitionMap, parse(value), col);
				}
			}
		}

		// read row definition
		for (int row = 1; row <= maxRow; row++) {
			Cell cell = getCell(sheet, row, 0);
			if (cell == null) {
				continue;
			}
			cell.setCellType( Cell.CELL_TYPE_STRING );
			String value = cell.getStringCellValue();
			if (value != null) {
				if (value.indexOf(',') > 0) {
					String[] valueArray = value.split(",");
					for (String tmpValue : valueArray) {
						addRowDefinition(tableDefinitionMap, parse(tmpValue), row);
					}
				} else {
					addRowDefinition(tableDefinitionMap, parse(value), row);
				}
			}
		}
		return tableDefinitionMap;
	}

	/**
	 * Add column definition given as 2nd and 3rd argument to tableDefinitionMap given as 1st argument.
	 * This logic branches based on the value of def variable.
	 * For example, if the value starts with "VAL_" then it is a single value definition, otherwise, it is a table definition.
	 * 
	 * @param tableDefinitionMap
	 * @param def
	 * @param columnNum
	 */
	private void addColumnDefinition(Map<String, ExcelDefinition> tableDefinitionMap, DefinitionStringWrapper def, int columnNum) {
		if (def == null) {
			return;
		}
		if (def.isSingleValue()) {
			ExcelDefinition tableDefinition = tableDefinitionMap.get(def.getWrappedDefinition());
			if (tableDefinition == null) {
				tableDefinition = new ExcelDefinition(false, def.getWrappedDefinition());
				tableDefinitionMap.put(def.getWrappedDefinition(), tableDefinition);
			}
			tableDefinition.addSingleValueCol(def.getWrappedDefinition(), columnNum, def.getValueType());
		} else if (def.isTable()) {
			// if the definition starts with "TAB_", then it is treated as a definition for table, and table name will follow after "TAB_". 
			// For example, the definition should be something like "TAB_MYTABLE#PAR_MYPARAM" 
			String tableName = def.getTableName();
			ExcelDefinition tableDefinition = tableDefinitionMap.get(tableName);
			if (tableDefinition == null) {
				tableDefinition = new ExcelDefinition(true, tableName);
				tableDefinitionMap.put(tableName, tableDefinition);
			}
			if (def.isTableValue()) {
				tableDefinition.addValueCol(def.getTableValueName(), columnNum, def.getValueType());
			} else if (def.isTableParameter()) {
				tableDefinition.addParamCol(def.getTableValueName(), columnNum, def.getValueType());
			} else {
				throw new RuntimeException("Illegal column name: " + def);
			}
		}
	}
	
	/**
	 * Add row definition given as 2nd and 3rd argument to tableDefinitionMap given as 1st argument.
	 * This logic branches based on the value of def variable.
	 * For example, if the value starts with "VAL_" then it is a single value definition, otherwise, it is a table definition.
	 * 
	 * @param tableDefinitionMap
	 * @param def
	 * @param columnNum
	 */
	private void addRowDefinition(Map<String, ExcelDefinition> tableDefinitionMap, DefinitionStringWrapper def, int rowNum) {
		if (def == null) {
			return;
		}
		if (def.isSingleValue()) {
			ExcelDefinition tableDefinition = tableDefinitionMap.get(def.getWrappedDefinition());
			if (tableDefinition == null) {
				tableDefinition = new ExcelDefinition(false, def.getWrappedDefinition());
				tableDefinitionMap.put(def.getWrappedDefinition(), tableDefinition);
			}
			tableDefinition.addSingleValueRow(def.getWrappedDefinition(), rowNum);
		} else if (def.isTable()) {
			// if the definition starts with "TAB_", then it is treated as a definition for table, and table name will follow after "TAB_". 
			// For example, the definition should be something like "TAB_MYTABLE_PAR_MYPARAM" 
			String tableName = def.getTableName();
			ExcelDefinition tableDefinition = tableDefinitionMap.get(tableName);
			if (tableDefinition == null) {
				tableDefinition = new ExcelDefinition(true, tableName);
				tableDefinitionMap.put(tableName, tableDefinition);
			}
			if (def.isStart()) {
				tableDefinition.setStartRow(rowNum);
			} else if (def.isCondition()) {
				tableDefinition.setConditionRow(rowNum);
			} else {
				throw new RuntimeException("Illegal column name: " + def);
			}
		}
	}

	private static DefinitionStringWrapper parse(String definition) {
		if (definition == null || definition.trim().length() == 0) {
			return null;
		}
		definition = definition.trim();
		DefinitionStringWrapper ret = new DefinitionStringWrapper(definition);
		ret.setSingleValue(definition.startsWith(VALUE_PREFIX));
		ret.setTable(definition.startsWith(TABLE_PREFIX));
		if (ret.isSingleValue()) {
			ret.setValueName(definition);
		} else if (ret.isTable()) {
			if (!definition.contains(TABLE_DELIMITER)) {
				throw new IllegalStateException("Illegal excel table definition. Definition starts with \"TAB_\" should contain \"#\" between table name and column/row name.: " + definition);
			}
			String[] tableDef = definition.split(TABLE_DELIMITER);
			ret.setTableName(tableDef[0]);
			String tmp = tableDef[1];
			if (tmp.startsWith(TABLE_PARAMETER_PREFIX)) {
				ret.setTableParameter(true);
				if (tableDef.length >= 3) {
					String valueType = tableDef[2];
					if (VALUE_TYPE_TRY_ANY.equals(valueType)) {
						ret.setValueType(ValueType.valueOf(valueType));
					} else {
						throw new IllegalStateException("Illegal excel table definition: " + definition);		
					}
				}
			} else if (tmp.startsWith(TABLE_VALUE_PREFIX)) {
				ret.setTableValue(true);
				if (tableDef.length >= 3) {
					String valueType = tableDef[2];
					if (VALUE_TYPE_TEXT.equals(valueType)) {
						ret.setValueType(ValueType.valueOf(valueType));
					} else if (VALUE_TYPE_NUM.equals(valueType)) {
						ret.setValueType(ValueType.valueOf(valueType));
					} else {
						throw new IllegalStateException("Illegal excel table definition: " + definition);		
					}
				}
			} else if (tmp.startsWith(TABLE_DATA_START)) {
				ret.setStart(true);
			} else if (tmp.startsWith(TABLE_CONDITION)) {
				ret.setCondition(true);
			} else {
				throw new IllegalStateException("Illegal excel table definition: " + definition);
			}
			ret.setValueName(tmp);
		} else {
			throw new IllegalStateException("Illegal excel table definition: " + definition);
		}
		return ret;
	}
	
	private static class DefinitionStringWrapper {

		private String definition;
		private boolean singleValue;
		private boolean table;
		private boolean tableParameter;
		private boolean tableValue;
		private boolean start;
		private boolean condition;
		private String valueName;
		private String tableName;
		private ValueType valueType;
		
		
		public DefinitionStringWrapper(String definition) {
			this.definition = definition.trim();
		}
		public boolean isSingleValue() {
			return singleValue;
		}
		public boolean isTable() {
			return table;
		}
		public boolean isTableParameter() {
			return tableParameter;
		}
		public boolean isTableValue() {
			return tableValue;
		}
		public boolean isStart() {
			return start;
		}
		public boolean isCondition() {
			return condition;
		}
		public String getWrappedDefinition() {
			return definition;
		}
		public String getTableName() {
			return tableName;
		}
		public String getTableValueName() {
			return valueName;
		}
		public void setValueName(String valueName) {
			this.valueName = valueName;
		}
		public void setSingleValue(boolean singleValue) {
			this.singleValue = singleValue;
		}
		public void setTable(boolean table) {
			this.table = table;
		}
		public void setTableParameter(boolean tableParameter) {
			this.tableParameter = tableParameter;
		}
		public void setTableValue(boolean tableValue) {
			this.tableValue = tableValue;
		}
		public void setStart(boolean start) {
			this.start = start;
		}
		public void setTableName(String tableName) {
			this.tableName = tableName;
		}
		public void setCondition(boolean condition) {
			this.condition = condition;
		}
		public ValueType getValueType() {
			return valueType;
		}
		public void setValueType(ValueType valueType) {
			this.valueType = valueType;
		}
	}
	
	
	public static Cell getCell(Sheet sheet, int row, int col) {
		Row r = sheet.getRow(row);
		if (r == null) {
			return null;
		}
		return r.getCell(col);
	}
	
	private ExcelTableData loadData(Sheet sheet, ExcelDefinition definition) {
		ExcelTableData retData = null;
		if (definition.isTable()) {
			retData = loadTableData(sheet, definition);
		} else {
			retData = loadSingleData(sheet, definition);
		}
		return retData;
	}
	
	private ExcelTableData loadSingleData(Sheet sheet, ExcelDefinition definition) {
		ExcelTableData data = createExcelTableData(definition);
		Cell cell = BaseExcelTableReader.getCell(sheet, definition.getSingleValue().getRow(), definition.getSingleValue().getCol());
		String value = null;
		if (cell != null) {
			cell.setCellType( Cell.CELL_TYPE_STRING );
			value = cell.getStringCellValue();
		}
		data.setValue(value);
		return data;
	}

	private ExcelTableData loadTableData(Sheet sheet, ExcelDefinition definition) {
		ExcelTableData retData = createExcelTableData(definition);
		int row = definition.getStartRow().getRow();
		while (true) {
			ExcelTableDataRow dataRow = new ExcelTableDataRow();
			for (ExcelCellAddress cellDef : definition.getParameterColMap().values()) {
				int col = cellDef.getCol();
				Cell dataCell = BaseExcelTableReader.getCell(sheet, row, col);
				if (dataCell != null) {
					dataRow.addParameter(cellDef.getValueName(), getCellValue(dataCell, true));
				}
			}
			for (ExcelCellAddress cellDef : definition.getValueColMap().values()) {
				int col = cellDef.getCol();
				Cell dataCell = BaseExcelTableReader.getCell(sheet, row, col);
				if (dataCell != null) {
					dataRow.addValue(cellDef.getValueName(), getCellValue(dataCell, cellDef.getValueType()));
				}
			}
			row++;
//			if (row % 1000 == 0) {
//				System.out.println("loaded:" + row);
//			}
			if (dataRow.isEmpty()) {
				break;
			} else {
				retData.addRow(dataRow);
			}
		}
		if (definition.isConditionDefined()) {
			for (ExcelCellAddress cellDef : definition.getParameterColMap().values()) {
				int col = cellDef.getCol();
				Cell dataCell = BaseExcelTableReader.getCell(sheet, definition.getConditionRow().getRow(), col);
				if (dataCell != null) {
					retData.addDecisionTableCondition(cellDef.getValueName(), getCellValue(dataCell));
				}
			}
			for (ExcelCellAddress cellDef : definition.getValueColMap().values()) {
				int col = cellDef.getCol();
				Cell dataCell = BaseExcelTableReader.getCell(sheet, definition.getConditionRow().getRow(), col);
				if (dataCell != null) {
					retData.addDecisionTableValue(cellDef.getValueName(), getCellValue(dataCell, cellDef.getValueType()));
				}
			}

		}
		return retData;
	}
	
	protected ExcelTableData createExcelTableData(ExcelDefinition definition) {
		return new ExcelTableData(definition);
	}
	
	private static String getCellValue(Cell cell) {
		return getCellValue(cell, null);
	}
	
	private static String getCellValue(Cell cell, boolean forceString) {
		return getCellValue(cell, ValueType.TEXT);
	}
	
	private static String getCellValue(Cell cell, ValueType valueType) {
		String ret = null;
		switch (cell.getCellType()) {
		case Cell.CELL_TYPE_STRING :
			ret = cell.getStringCellValue();
			break;
		case Cell.CELL_TYPE_NUMERIC:
			ret = String.valueOf(cell.getNumericCellValue());
			break;
		case Cell.CELL_TYPE_BOOLEAN:
			ret = String.valueOf(cell.getBooleanCellValue());
			break;
		case Cell.CELL_TYPE_FORMULA:
//			CreationHelper helper = cell.getSheet().getWorkbook().getCreationHelper();
//		    FormulaEvaluator evaluator = helper.createFormulaEvaluator();
//		    Cell c = evaluator.evaluateInCell(cell);
//		    ret = getCellValue(c);
			
			if (valueType == null) {
				try {
					ret = String.valueOf(cell.getNumericCellValue());
				} catch (IllegalStateException e) {
					ret = cell.getStringCellValue();
				}
			} else {
				if(ValueType.TEXT.equals(valueType)){
					ret = cell.getStringCellValue();
				} else if (ValueType.NUM.equals(valueType)) {
					ret = String.valueOf(cell.getNumericCellValue());
				} else {
					throw new UnsupportedOperationException("Not implemented");
				}
			}
				
			break;
		default:
			ret = cell.getStringCellValue();
			break;
		}
		return ret;
	}
}
