package com.axa.adj.api.validation;

import com.axa.adj.api.BaseAPILifecycleContext;

public interface APIValidator {
	APIValidationContext validate(BaseAPILifecycleContext context);
}
