package com.axa.adj.util.exceltable.dto;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

public class ExcelTableContext {

	private Map<String, ExcelTableData> excelTableDataMap = new HashMap<>();
	
	@SuppressWarnings("unchecked")
	public <T extends ExcelTableData> T get(String tableOrSingleValueName) {
		return (T)excelTableDataMap.get(tableOrSingleValueName);
	}
	
	public void addExcelTableData(ExcelTableData data) {
		excelTableDataMap.put(data.getName(), data);
	}
	
	public void merge(ExcelTableContext context) {
		getExcelTableDataMap().putAll(context.getExcelTableDataMap());
	}

	public Map<String, ExcelTableData> getExcelTableDataMap() {
		return excelTableDataMap;
	}

	public void setExcelTableDataMap(Map<String, ExcelTableData> excelTableDataMap) {
		this.excelTableDataMap = excelTableDataMap;
	}
	
	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		for (Entry<String, ExcelTableData> entry: excelTableDataMap.entrySet()) {
			sb.append(entry.getKey());
			sb.append("\t");
			sb.append(entry.getValue());
			sb.append("\n");
		}
		return sb.toString();
	}
}
