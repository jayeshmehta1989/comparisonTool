package com.axa.adj.util.exceltable;

public interface ExcelTableWriter {

}
