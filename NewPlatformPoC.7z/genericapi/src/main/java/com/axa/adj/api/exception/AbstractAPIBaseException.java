package com.axa.adj.api.exception;

/**
 * Super class for every API V2.0 exceptions.
 */
public abstract class AbstractAPIBaseException extends RuntimeException {

	private static final long serialVersionUID = 37536245540460013L;
	private String errorCode;
	private String errorMessage;

	public AbstractAPIBaseException(String errorCode) {
		this(errorCode, null, null);
	}
	public AbstractAPIBaseException(String errorCode, String[] args) {
		this(errorCode, args, null);
	}
	public AbstractAPIBaseException(String errorCode, String[] args, Throwable cause) {
		super(createErrorMessage(errorCode, args), cause);
		setupError(errorCode, args);
	}
	protected static String createErrorMessage(String errorCode, String[] args) {
		return errorCode + ":" + APIV2_0ExceptionMessageHolder.getInstance().getValue(errorCode, args);
	}
	
	protected void setupError(String errorCode, String[] args) {
		this.errorCode = errorCode;
		this.errorMessage = APIV2_0ExceptionMessageHolder.getInstance().getValue(errorCode, args);
	}
	
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}
	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
}
