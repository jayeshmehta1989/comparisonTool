require('bootstrap-loader');


require('./app.tag');

require('../style/dashboard.css');

riot.mount('*');

