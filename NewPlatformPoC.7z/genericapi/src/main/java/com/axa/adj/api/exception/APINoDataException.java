package com.axa.adj.api.exception;

public class APINoDataException extends APIBaseApplicationException {

	private static final long serialVersionUID = 2712569336930144227L;

	public APINoDataException() {
		super("EC_002");
	}

}
