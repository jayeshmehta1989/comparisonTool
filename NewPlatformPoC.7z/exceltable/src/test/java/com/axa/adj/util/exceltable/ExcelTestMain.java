package com.axa.adj.util.exceltable;
import java.io.File;

import com.axa.adj.util.exceltable.BaseExcelTableReader;
import com.axa.adj.util.exceltable.dto.ExcelTableContext;

public class ExcelTestMain {

	public static void main(String[] args) {
		File templateExcelFile = new File("template/ClaimVerificationDocument.xlsx");
		ExcelTableContext context = new BaseExcelTableReader().read(templateExcelFile);
		System.out.println(context);
	}
}
