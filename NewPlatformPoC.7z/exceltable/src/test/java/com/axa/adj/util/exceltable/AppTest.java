package com.axa.adj.util.exceltable;

import java.io.File;
import java.util.HashMap;

import org.junit.Test;

import com.axa.adj.util.exceltable.dto.ExcelTableContext;
import com.axa.adj.util.exceltable.dto.ExcelTableData;
import com.axa.adj.util.exceltable.dto.ExcelTableData.ExcelTableDataRow;

/**
 * Unit test for simple App.
 */
public class AppTest {
	/**
	 * Rigourous Test :-)
	 */
	@Test
	public void sample() {
		File templateExcelFile = new File("target/Gradle_ConnectionSettings.xlsx");
		ExcelTableContext context = new BaseExcelTableReader().read(templateExcelFile);
		System.out.println(context);

		ExcelTableData table = context.get("TAB_MULE_CONFIG");
		@SuppressWarnings("serial")
		ExcelTableDataRow row = table.findRow(new HashMap<String, String>() {
			{
				put("PAR_APPLICATION_NAME", "AXA_ADJ_APIGatewayPrivate");
				put("PAR_ENV", "DEV");
			}
		});

		System.out.println(row.getValue("VAL_MMC_URL"));
	}
}
