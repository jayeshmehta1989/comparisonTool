package com.axa.adj.util.exceltable;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

import com.axa.adj.util.exceltable.dto.ExcelTableData;

public class BaseExcelTableWriter {

	public void write(File templateFile, String templateSheetName, File outputFile, String outputSheetName) {
//		Workbook wb = new HSSFWorkbook();
		Workbook wb;
		try {
			wb = WorkbookFactory.create(templateFile);
		} catch (EncryptedDocumentException | InvalidFormatException | IOException e) {
			throw new RuntimeException(e);
		}
		int templateSheetIndex = wb.getSheetIndex(templateSheetName);
		Sheet sheet = wb.cloneSheet(templateSheetIndex);
		wb.setSheetName(wb.getSheetIndex(sheet), outputSheetName);
		

	    
	    try (FileOutputStream out = new FileOutputStream(outputFile);){
	      wb.write(out);
	    }catch(IOException e){
	      System.out.println(e.toString());
	    }
	}
	
	public void write(Sheet sheet, List<ExcelTableData> dataList) {
		
	}
}
