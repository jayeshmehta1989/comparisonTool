package com.axa.adj.api;

import java.lang.reflect.Method;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.HandlerMapping;
import org.springframework.web.servlet.mvc.condition.ConsumesRequestCondition;
import org.springframework.web.servlet.mvc.condition.HeadersRequestCondition;
import org.springframework.web.servlet.mvc.condition.ParamsRequestCondition;
import org.springframework.web.servlet.mvc.condition.PatternsRequestCondition;
import org.springframework.web.servlet.mvc.condition.ProducesRequestCondition;
import org.springframework.web.servlet.mvc.condition.RequestMethodsRequestCondition;
import org.springframework.web.servlet.mvc.method.RequestMappingInfo;
import org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerMapping;

@RestController
@EnableAutoConfiguration
public class App {
 
    @RequestMapping(path="/home", method=RequestMethod.GET)
    @ResponseBody
    public String home() {
        return "Hello, Spring Boot!";
    }

	@RequestMapping(value = "/sample", method = RequestMethod.POST, consumes = MediaType.APPLICATION_JSON_VALUE)
    public String sample(TestBean bean) {
    	return "this is a sample API";
    }
    
    public String test() {
    	return "This is a test!";
    }
 
    public static void main(String[] arguments) {
        SpringApplication.run(App.class, arguments);
    }
    
//    @Bean
//    public RequestMappingHandlerMapping getHandlerMapping() {
//    	
//    	return new RequestMappingHandlerMapping() {
//    		@Override
//    		public Map<RequestMappingInfo, HandlerMethod> getHandlerMethods() {
//    			System.out.println("getHandlerMethods");
//    			Map<RequestMappingInfo, HandlerMethod> ret = super.getHandlerMethods();
////    			System.out.println(ret);
//    			Map<RequestMappingInfo, HandlerMethod> ret2 = new HashMap<>();
//    			try {
//    				for (Entry<RequestMappingInfo, HandlerMethod> entry:ret.entrySet()) {
////        				System.out.println(entry.getValue());
//    					RequestMappingInfo key = entry.getKey();
//        				HandlerMethod m = entry.getValue();
//        				HandlerMethod m2 = new HandlerMethod(m.getBean(), App.class.getMethod("test", null));
//        				ret2.put(key, m2);	
//        			}
//    			} catch (Exception e) {
//    				e.printStackTrace();
//    			}
//    			
//    			
//    			return ret2;
//    		}
//    		@Override
//    		public List<HandlerMethod> getHandlerMethodsForMappingName(String mappingName) {
//    			System.out.println("getHandlerMethodsForMappingName");
//    			return super.getHandlerMethodsForMappingName(mappingName);
//    		}
//    		@Override
//    		public void registerMapping(RequestMappingInfo mapping, Object handler, Method method) {
//    			System.out.println("registerMapping");
//    			super.registerMapping(mapping, handler, method);
//    		}
//    		@Override
//    		public void afterPropertiesSet() {
//    			System.out.println("afterPropertiesSet");
//    			super.afterPropertiesSet();
//    		}
//    		@Override
//    		protected HandlerMethod lookupHandlerMethod(String lookupPath, HttpServletRequest request)
//    				throws Exception {
//    			System.out.println(lookupPath);
//    			return super.lookupHandlerMethod(lookupPath, request);
//    		}
//    		@Override
//    		protected HandlerMethod getHandlerInternal(HttpServletRequest request) throws Exception {
//    			System.out.println("getHandlerInternal");
//    			return super.getHandlerInternal(request);
//    		}
//    		@Override
//    		public Object getDefaultHandler() {
//    			System.out.println("getDefaultHandler");
//    			return super.getDefaultHandler();
//    		}
//    		@Override
//    		protected Set<String> getMappingPathPatterns(RequestMappingInfo info) {
//    			System.out.println("getMappingPathPatterns");
//    			return super.getMappingPathPatterns(info);
//    		}
//    		@Override
//    		protected RequestMappingInfo getMatchingMapping(RequestMappingInfo info, HttpServletRequest request) {
//    			System.out.println("getMatchingMapping");
//    			return super.getMatchingMapping(info, request);
//    		}
//    		@Override
//    		protected void handleMatch(RequestMappingInfo info, String lookupPath, HttpServletRequest request) {
//    			System.out.println("handleMatch");
//    			super.handleMatch(info, lookupPath, request);
//    		}
//    		
//    		@Override
//    		protected HandlerExecutionChain getHandlerExecutionChain(Object handler, HttpServletRequest request) {
//    			System.out.println("getHandlerExecutionChain");
//    			return super.getHandlerExecutionChain(handler, request);
//    		}
//    	};
//    }
 
    @Bean
    public HandlerMapping getHandlerMapping() {

    	RequestMappingHandlerMapping obj = new RequestMappingHandlerMapping2();
    	return obj;
    }
    
    class RequestMappingHandlerMapping2 extends RequestMappingHandlerMapping {
    	
    	public RequestMappingHandlerMapping2() {
    		setOrder(-1);
    	}
//		@Override
//		public Map<RequestMappingInfo, HandlerMethod> getHandlerMethods() {
//			System.out.println("getHandlerMethods");
//			Map<RequestMappingInfo, HandlerMethod> ret = super.getHandlerMethods();
////			System.out.println(ret);
//			Map<RequestMappingInfo, HandlerMethod> ret2 = new HashMap<>();
//			try {
//				for (Entry<RequestMappingInfo, HandlerMethod> entry:ret.entrySet()) {
////    				System.out.println(entry.getValue());
//					RequestMappingInfo key = entry.getKey();
//    				HandlerMethod m = entry.getValue();
//    				HandlerMethod m2 = new HandlerMethod(m.getBean(), App.class.getMethod("test", null));
//    				ret2.put(key, m2);	
//    			}
//			} catch (Exception e) {
//				e.printStackTrace();
//			}
//			
//			
//			return ret2;
//		}
//		@Override
//		public List<HandlerMethod> getHandlerMethodsForMappingName(String mappingName) {
//			System.out.println("getHandlerMethodsForMappingName");
//			return super.getHandlerMethodsForMappingName(mappingName);
//		}
//		@Override
//		public void registerMapping(RequestMappingInfo mapping, Object handler, Method method) {
//			System.out.println("registerMapping");
//			super.registerMapping(mapping, handler, method);
//		}
//		@Override
//		public void afterPropertiesSet() {
//			System.out.println("afterPropertiesSet");
//			super.afterPropertiesSet();
//		}
//		@Override
//		protected HandlerMethod lookupHandlerMethod(String lookupPath, HttpServletRequest request)
//				throws Exception {
//			System.out.println(lookupPath);
//			return super.lookupHandlerMethod(lookupPath, request);
//		}
//		@Override
//		protected HandlerMethod getHandlerInternal(HttpServletRequest request) throws Exception {
//			System.out.println("getHandlerInternal");
//			return super.getHandlerInternal(request);
//		}
//		@Override
//		public Object getDefaultHandler() {
//			System.out.println("getDefaultHandler");
//			return super.getDefaultHandler();
//		}
//		@Override
//		protected Set<String> getMappingPathPatterns(RequestMappingInfo info) {
//			System.out.println("getMappingPathPatterns");
//			return super.getMappingPathPatterns(info);
//		}
//		@Override
//		protected RequestMappingInfo getMatchingMapping(RequestMappingInfo info, HttpServletRequest request) {
//			System.out.println("getMatchingMapping");
//			return super.getMatchingMapping(info, request);
//		}
//		@Override
//		protected void handleMatch(RequestMappingInfo info, String lookupPath, HttpServletRequest request) {
//			System.out.println("handleMatch");
//			super.handleMatch(info, lookupPath, request);
//		}
//		
//		@Override
//		protected HandlerExecutionChain getHandlerExecutionChain(Object handler, HttpServletRequest request) {
//			System.out.println("getHandlerExecutionChain");
//			return super.getHandlerExecutionChain(handler, request);
//		}
		@Override
		protected void registerHandlerMethod(Object handler, Method method, RequestMappingInfo mapping) {
			System.out.println("registerHandlerMethod");
			RequestMappingInfo info = new RequestMappingInfo(null, 
					new PatternsRequestCondition(""), 
					new RequestMethodsRequestCondition(RequestMethod.POST),
					new ParamsRequestCondition(""),
					new HeadersRequestCondition(""),
					new ConsumesRequestCondition(""),
					new ProducesRequestCondition(""),
					null);
//			RequestMappingInfo info = new RequestMappingInfo(null, 
//					new PatternsRequestCondition(""), 
//					new RequestMethodsRequestCondition(RequestMethod.POST),
//					null,
//					null,
//					null,
//					null,
//					null);
			super.registerHandlerMethod(handler, method, mapping);
		}
		@Override
		protected void initHandlerMethods() {
			super.initHandlerMethods();
		}
    	
    	
	}
}