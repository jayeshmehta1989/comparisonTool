package com.axa.adj.util.exceltable.dto;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.axa.adj.util.exceltable.dto.ExcelDefinition.ExcelCellAddress.CellType;
import com.axa.adj.util.exceltable.dto.ExcelDefinition.ExcelCellAddress.ValueType;

/**
 * Class to represent definition of a table or all the single values in one sheet.  
 * 
 */
public class ExcelDefinition {

	private boolean tableFlag = false;
	/**
	 * used for table only.
	 */
	private String name;
	/**
	 * used for table only.
	 */
	private Map<String, ExcelCellAddress> parameterColMap = new HashMap<>();
	/**
	 * used for table only.
	 */
	private Map<String, ExcelCellAddress> valueColMap = new HashMap<>();
	/**
	 * used for table only.
	 */
	private ExcelCellAddress startRow = null;
	/**
	 * used for table only.
	 */
	private ExcelCellAddress conditionRow = null;
	/**
	 * used for single value only.
	 */
	private ExcelCellAddress singleValue;
	

	public ExcelDefinition(boolean isTable, String name) {
		this.tableFlag = isTable;
		this.name = name;
	}
	public int getColumnNum(String columnName) {
		int ret = getColumnNumInternal(parameterColMap, columnName);
		if (ret != ExcelCellAddress.NO_ROWCOL_VALUE) {
			return ret;
		}
		ret = getColumnNumInternal(valueColMap, columnName);
		if (ret != ExcelCellAddress.NO_ROWCOL_VALUE) {
			return ret;
		}
		return singleValue.getCol();
	}
	/**
	 * If this definition is for Table, returns true.
	 * If this definition is for a single data, returns false.
	 * @return
	 */
	public boolean isTable() {
		return tableFlag;
	}
	
	public void addSingleValueCol(String valueName, int col, ValueType valueType) {
		if (singleValue == null) {
			singleValue = new ExcelCellAddress(valueName, CellType.SINGLE_VALUE, valueType);
		}
		singleValue.setCol(col);
	}
	
	public void addSingleValueRow(String valueName, int row) {
		if (singleValue == null) {
			singleValue = new ExcelCellAddress(valueName, CellType.SINGLE_VALUE, null);
		}
		singleValue.setRow(row);
	}
	
	public void addValueCol(String valueColumnName, int col, ValueType valueType) {
		ExcelCellAddress cell = valueColMap.get(valueColumnName);
		if (cell == null) {
			cell = new ExcelCellAddress(valueColumnName, CellType.TABLE_VALUE, valueType);
			valueColMap.put(valueColumnName, cell);
		}
		cell.setCol(col);
	}
	
	public void addParamCol(String paramColumnName, int col, ValueType valueType) {
		ExcelCellAddress cell = parameterColMap.get(paramColumnName);
		if (cell == null) {
			cell = new ExcelCellAddress(paramColumnName, CellType.TABLE_PARAMETER, valueType);
			parameterColMap.put(paramColumnName, cell);
		}
		cell.setCol(col);
	}
	
	public void setStartRow(int row) {
		if (startRow == null) {
			startRow = new ExcelCellAddress("START", CellType.TABLE_START_ROW, null); 
		}
		startRow.setRow(row);
	}
	
	public void setConditionRow(int row) {
		if (conditionRow == null) {
			conditionRow = new ExcelCellAddress("CONDITION", CellType.TABLE_CONDITION_ROW, null);
		}
		conditionRow.setRow(row);
	}
	
	public static class ExcelCellAddress {

		public static enum ValueType{TEXT, NUM, TRY_ANY};
		public static enum CellType{TABLE_PARAMETER, TABLE_VALUE, TABLE_CONDITION_ROW, TABLE_START_ROW, SINGLE_VALUE, };
		public static final int NO_ROWCOL_VALUE = -1;
		private CellType type;
		private String valueName;
		private int row = NO_ROWCOL_VALUE;
		private int col = NO_ROWCOL_VALUE;
		private ValueType valueType;
		
		public ExcelCellAddress(String name, CellType type, ValueType valueType) {
			this.valueName = name;
			this.type = type;
			this.valueType = valueType;
		}
		public int getRow() {
			return row;
		}
		public void setRow(int row) {
			this.row = row;
		}
		public boolean isRowNoValue() {
			return getRow() == NO_ROWCOL_VALUE;
		}
		public int getCol() {
			return col;
		}
		public void setCol(int col) {
			this.col = col;
		}
		public boolean isColNoValue() {
			return getCol() == NO_ROWCOL_VALUE;
		}
		public String getValueName() {
			return valueName;
		}
		public void setValueName(String valueName) {
			this.valueName = valueName;
		}
		@Override
		public String toString() {
			StringBuilder sb = new StringBuilder();
			sb.append("{");
			sb.append("row:");
			sb.append(row);
			sb.append(", column:");
			sb.append(col);
			sb.append("}");
			return sb.toString();
		}
		public CellType getType() {
			return type;
		}
		public void setType(CellType type) {
			this.type = type;
		}
		public ValueType getValueType() {
			return valueType;
		}
		public void setValueType(ValueType valueType) {
			this.valueType = valueType;
		}
	}

	public ExcelCellAddress getStartRow() {
		return startRow;
	}
	public Map<String, ExcelCellAddress> getParameterColMap() {
		return parameterColMap;
	}
	public Map<String, ExcelCellAddress> getValueColMap() {
		return valueColMap;
	}

	private int getColumnNumInternal(Map<String, ExcelCellAddress> map, String columnName) {
		if (map.containsKey(columnName)) {
			ExcelCellAddress cell = map.get(columnName);
			if (cell.isColNoValue()) {
				return ExcelCellAddress.NO_ROWCOL_VALUE;
			} else {
				return map.get(columnName).getCol();	
			}
		}
		return ExcelCellAddress.NO_ROWCOL_VALUE;
	}
	public ExcelCellAddress getSingleValue() {
		return singleValue;
	}
	
	public List<String> getParameterKeys() {
		List<String> paramKeys = new ArrayList<>(getParameterColMap().keySet());
		paramKeys.sort(Comparator.comparing(x -> getColumnNum(x)));
		return paramKeys;
	}
	public List<String> getValueKeys() {
		List<String> valueKeys = new ArrayList<>(getValueColMap().keySet());
		valueKeys.sort(Comparator.comparing(x -> getColumnNum(x)));
		return valueKeys;
	}
	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder();
		
		sb.append("{");
		sb.append("isTable:" + isTable());
		sb.append(", ");
		sb.append("name:" + name);
		sb.append(", ");
		if (isTable()) {
			sb.append("[" + getParameterKeys() + "], [" + getValueKeys() + "]");
		} else {
			sb.append("cell:" + singleValue);
		}
		sb.append("}");
		return sb.toString();
	}
	public String getName() {
		return name;
	}
	public ExcelCellAddress getConditionRow() {
		return conditionRow;
	}
	public boolean isConditionDefined() {
		return conditionRow != null;
	}
}
