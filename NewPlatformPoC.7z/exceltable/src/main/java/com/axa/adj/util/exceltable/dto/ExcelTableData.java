package com.axa.adj.util.exceltable.dto;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import com.axa.adj.util.exceltable.dto.ExcelDefinition.ExcelCellAddress;
import com.axa.adj.util.exceltable.dto.ExcelDefinition.ExcelCellAddress.ValueType;

public class ExcelTableData {

	private ExcelDefinition definition;
	
	private List<ExcelTableDataRow> dataList = new ArrayList<>();
	/**
	 * This map is used for indexing dataList.
	 * Create key for each item in the dataList and put it as a key of the item.  
	 */
	private Map<String, ExcelTableDataRow> indexMap = new HashMap<>();
	private String data = null;
	
	/**
	 * Map for conditions.
	 * Key will be a parameter name(e.g. PAR_COVERAGE), and Value will be a compiled object of MVEL logic. 
	 */
	private Map<String, String> decisionTableConditionMap = new HashMap<>();
	
	private Map<String, String> decisionTableValueMap = new HashMap<>();
	
	public ExcelTableData(ExcelDefinition definition) {
		this.definition = definition;
	}
	public boolean isTable() {
		return definition.isTable();
	}
	public String getName() {
		return definition.getName();
	}
	public void addRow(ExcelTableDataRow data) {
		dataList.add(data);
		indexMap.put(generateKey(data.getParamMap()), data);
	}
	
	protected String generateKey(Map<String, String> paramMap) {
		StringBuilder ret = new StringBuilder();
		
		for(String paramKey : definition.getParameterKeys()) {
			if (ret.length() != 0) {
				ret.append(',');
			}
			ret.append(paramKey).append(":").append(paramMap.get(paramKey));
		}
		return ret.toString();
	}
	
	protected boolean containsAnyCondition() {
		for (ExcelCellAddress cellDef : definition.getParameterColMap().values()) {
			if (ValueType.TRY_ANY.equals(cellDef.getValueType())) {
				return true;
			}
		}
		return false;
	}
	
	public void addDecisionTableCondition(String tableParameterName, String mvelExpression) {
		decisionTableConditionMap.put(tableParameterName, mvelExpression);
	}
	
	public void addDecisionTableValue(String tableValueName, String mvelExpression) {
		decisionTableValueMap.put(tableValueName, mvelExpression);
	}
	
	/**
	 * 
	 * @param key
	 * @return
	 */
	public ExcelTableDataRow findRow(Map<String, String> conditionMap) {
		ExcelTableDataRow ret = indexMap.get(generateKey(conditionMap));
		if (ret == null && containsAnyCondition()) {
			for (ExcelCellAddress cellDef : definition.getParameterColMap().values()) {
				if (ValueType.TRY_ANY.equals(cellDef.getValueType())) {
					conditionMap.put(cellDef.getValueName(), "#ANY#");
				}
			}
			ret = indexMap.get(generateKey(conditionMap));
		}
		return ret;
	}
	/**
	 * @param index
	 * @return
	 */
	public ExcelTableDataRow findRow(int index) {
		if (dataList.size() > index) {
			return dataList.get(index);
		}
		return null;
	}
	
	@SuppressWarnings("serial")
	public static class DataNotFoundException extends Exception {
		
	}
	
	/**
	 * 
	 * 
	 * @param columnName
	 * @return
	 */
	public List<String> list(String columnName) {
		List<String> retList = new ArrayList<>();
		for (ExcelTableDataRow row : dataList) {
			retList.add(row.getValue(columnName));
		}
		return retList;
	}
	/**
	 * Returns dataList in unmodifiable form.
	 * 
	 * @return
	 */
	public List<ExcelTableDataRow> getAllData() {
		return Collections.unmodifiableList(dataList);
	}
	/**
	 * can only be used for single value.
	 * @return
	 */
	public String getValue() {
		if (isTable()) {
			throw new UnsupportedOperationException(this.getClass().getName() + "#getValue is available only for single value.");
		}
		return data;
	}
	public void setValue(String value) {
		if (isTable()) {
			throw new UnsupportedOperationException(this.getClass().getName() + "#setValue is available only for single value.");
		}
		this.data = value;
	}
	public ExcelDefinition getDefinition() {
		return definition;
	}
	
	@Override
	public String toString() {

		StringBuilder sb = new StringBuilder();
//		sb.append(definition).append("\r\n");
		if (isTable()) {
			
			List<String> paramKeys = definition.getParameterKeys();
			List<String> valueKeys = definition.getValueKeys();
			
			for (ExcelTableDataRow row : dataList) {
				List<String> paramValues = new ArrayList<>();
				List<String> valueValues = new ArrayList<>();
				for (String key : paramKeys) {
					paramValues.add(row.getParamMap().get(key));
				}
				for (String key : valueKeys) {
					valueValues.add(row.getValueMap().get(key));
				}
				sb.append(paramValues + "," + valueValues);
				sb.append("\r\n");
			}
			
		} else {
			sb.append(data);
		}
		return sb.toString();
	}

	public static class ExcelTableDataRow {
		private Map<String, String> paramMap = new HashMap<>();
		private Map<String, String> valueMap = new HashMap<>();

		/**
		 * Add parameter to BOTH paramMap and valueMap. 
		 * 
		 * @param columnName
		 * @param value
		 */
		public void addParameter(String columnName, String value) {
			valueMap.put(columnName, value);
			paramMap.put(columnName, value);
		}
		public void addValue(String columnName, String value) {
			valueMap.put(columnName, value);
		}
		/**
		 * This instance is empty when no item inside both of paramMap and valueMap, OR, all the item is blank space
		 * @return
		 */
		public boolean isEmpty() {
			
			if (paramMap.size() == 0 && valueMap.size() == 0) {
				return true;	
			} else {
				for (String item : paramMap.values()) {
					if (item != null && !item.isEmpty()) {
						return false;
					}
				}
				for (String item : valueMap.values()) {
					if (item != null && !item.isEmpty()) {
						return false;
					}
				}
				return true;
			}
			
		}
		public Map<String, String> getParamMap() {
			return paramMap;
		}
		/**
		 * Both values(VAL_) and parameters(PAR_) are in this map.
		 * To get only values, you have to remove parameters by using getParamMap() 
		 * 
		 * @return 
		 */
		public Map<String, String> getValueMap() {
			return valueMap;
		}
		public boolean matches(Map<String, String> targetParamMap) {
			if (targetParamMap.size() != paramMap.size()) {
				return false;
			}
			for (Entry<String, String> entry : targetParamMap.entrySet()) {
				if (!entry.getValue().equals(paramMap.get(entry.getKey()))) {
					return false;
				}
			}
			return true;
		}
		/**
		 * Returns only parameter.
		 * 
		 * @param columnName
		 * @return
		 */
		public String getParam(String columnName) {
			return paramMap.get(columnName);
		}
		/**
		 * Returns value and parameter.
		 * 
		 * @param columnName
		 * @return
		 */
		public String getValue(String columnName) {
			return valueMap.get(columnName);
		}
		public BigDecimal getDecimal(String columnName) {
			return new BigDecimal(getValue(columnName));
		}
		public Map<String, Object> toMap(Map<String, String> keyMappingMap) {
			Map<String, Object> retMap = new HashMap<>();
			for (Entry<String, String> entry : keyMappingMap.entrySet()) {
				retMap.put(entry.getValue(), getValue(entry.getKey()));
			}
			return retMap;
		}
	}

	public Map<String, ExcelTableDataRow> getIndexMap() {
		return indexMap;
	}
	public Map<String, String> getDecisionTableConditionMap() {
		return decisionTableConditionMap;
	}
	public Map<String, String> getDecisionTableValueMap() {
		return decisionTableValueMap;
	}

}
